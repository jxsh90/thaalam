"""Thaalam: Ableton Live Remote Script.

Select "Thaalam" as a Control Surface in
Settings > Link, Tempo & MIDI (Input: None, Output: None).
"""

from .Thaalam import Thaalam


def create_instance(c_instance):
    return Thaalam(c_instance)
