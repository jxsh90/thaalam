"""Thaalam server core.

Pure Python (3.7+ compatible). No Ableton imports here, so this module can be
unit-tested outside Live. The Ableton glue (Thaalam.py) supplies a song
adapter and calls ``tick()`` from Live's ``update_display`` callback, which Live
invokes on its main (UI/script) thread roughly every 100 ms.

Every socket is non-blocking. ``tick()`` never waits on the network, so the
script never stalls Live's UI thread and never touches the audio thread.

Safety rules enforced here:
* The only song properties ever written are ``tempo`` and ``metronome``.
* Nothing is written on connect, auth, disconnect, or shutdown.
* A tempo ramp (``ramp``) is stepped from ``tick()``. It runs to its target
  even if the phone disconnects, but stops at once on ``stop_ramp``, on any
  other tempo command, if anyone else changes the tempo, or when the script
  stops. Stopping never writes anything.
* Commands are only accepted on an authenticated connection, and a command
  that arrives too late (more than COMMAND_MAX_AGE_MS old) is rejected rather
  than applied, so a delayed packet can never apply stale intent.
"""

import errno
import hashlib
import hmac
import json
import os
import random
import socket
import time

PROTOCOL_VERSION = 1
DEFAULT_PORT = 47800
MIN_TEMPO = 20.0
MAX_TEMPO = 999.0
MAX_DELTA = 20.0
MAX_CLIENTS = 8
MAX_LINE_BYTES = 4096
COMMAND_MAX_AGE_MS = 1500
CLIENT_IDLE_TIMEOUT_S = 15.0
UNAUTH_TIMEOUT_S = 10.0
MAX_AUTH_FAILURES = 5
AUTH_LOCKOUT_S = 60.0
MAX_RAMP_SECONDS = 300.0
# A tempo further than this from the last value the ramp wrote means someone
# else (music director, Link peer, automation) changed it: the ramp yields.
RAMP_TAKEOVER_BPM = 0.05

_RNG = random.SystemRandom()


def _hex_token(nbytes):
    return "".join("%02x" % _RNG.randrange(256) for _ in range(nbytes))


def new_pairing_code():
    return "%06d" % _RNG.randrange(1000000)


def hmac_hex(key, message):
    return hmac.new(key.encode("utf-8"), message.encode("utf-8"),
                    hashlib.sha256).hexdigest()


def round_tempo(value):
    return round(float(value), 3)


class ConfigStore(object):
    """Pairing code + paired devices, stored as JSON (mode 0600)."""

    def __init__(self, path):
        self.path = path
        self.data = {"pairing_code": None, "devices": {}, "port": DEFAULT_PORT}
        self.load()

    def load(self):
        try:
            with open(self.path, "r") as f:
                loaded = json.load(f)
            if isinstance(loaded, dict):
                self.data.update(loaded)
        except (IOError, OSError, ValueError):
            pass
        if not isinstance(self.data.get("devices"), dict):
            self.data["devices"] = {}
        code = self.data.get("pairing_code")
        if not (isinstance(code, str) and len(code) == 6 and code.isdigit()):
            self.data["pairing_code"] = new_pairing_code()
            self.save()

    def save(self):
        folder = os.path.dirname(self.path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder, 0o700)
        tmp = self.path + ".tmp"
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump(self.data, f, indent=2, sort_keys=True)
        os.rename(tmp, self.path)

    @property
    def pairing_code(self):
        return self.data["pairing_code"]

    @property
    def port(self):
        try:
            return int(self.data.get("port", DEFAULT_PORT))
        except (TypeError, ValueError):
            return DEFAULT_PORT

    def device_token(self, device_id):
        entry = self.data["devices"].get(device_id)
        if isinstance(entry, dict):
            return entry.get("token")
        return None

    def add_device(self, device_id, name):
        self.load()
        token = _hex_token(32)
        self.data["devices"][device_id] = {
            "name": name, "token": token,
            "paired_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        self.save()
        return token


class SongAdapter(object):
    """Interface the server needs. Thaalam.py wraps Live's Song."""

    def get_tempo(self):
        raise NotImplementedError

    def set_tempo(self, bpm):
        raise NotImplementedError

    def get_metronome(self):
        raise NotImplementedError

    def set_metronome(self, on):
        raise NotImplementedError

    def is_playing(self):
        raise NotImplementedError


class _Client(object):
    def __init__(self, sock, addr, now):
        self.sock = sock
        self.addr = addr
        self.rbuf = b""
        self.wbuf = b""
        self.nonce = _hex_token(16)
        self.authed = False
        self.device = None
        self.clock_offset_ms = None
        self.last_rx = now
        self.connected_at = now
        self.closing = False
        self.last_sent_state = None
        # Highest command id from this client that has been processed. Sent as
        # "ack" in state messages so the phone knows exactly which of its
        # pending commands a given state already includes.
        self.last_id = 0


class RemoteServer(object):
    def __init__(self, song, config, log=None, notify=None,
                 live_version="unknown", host="0.0.0.0", port=None,
                 clock=time.monotonic, wall_ms=None):
        self.song = song
        self.config = config
        self.log = log or (lambda msg: None)
        self.notify = notify or (lambda msg: None)
        self.live_version = live_version
        self.host = host
        self.port = config.port if port is None else port
        self.clock = clock
        self.wall_ms = wall_ms or (lambda: int(time.time() * 1000))
        self.listener = None
        self.clients = []
        self.seq = 0
        self.state = None
        self.auth_failures = []
        self.locked_until = 0.0
        self.ramp = None  # dict(start, target, t0, seconds, last)

    # ----- lifecycle -------------------------------------------------------

    def start(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind((self.host, self.port))
        sock.listen(4)
        sock.setblocking(False)
        self.listener = sock
        self.port = sock.getsockname()[1]
        self.state = self._read_state()
        self.log("Thaalam listening on %s:%d" % (self.host, self.port))

    def stop(self):
        """Close sockets only. Never touches tempo, metronome or transport."""
        self.ramp = None
        for c in list(self.clients):
            self._close(c, "server stopping")
        self.clients = []
        if self.listener is not None:
            try:
                self.listener.close()
            except Exception:
                pass
            self.listener = None

    # ----- main loop -------------------------------------------------------

    def tick(self):
        if self.listener is None:
            return
        now = self.clock()
        self._accept(now)
        for c in list(self.clients):
            self._read(c, now)
        self._step_ramp(now)
        self._refresh_state()
        for c in list(self.clients):
            limit = CLIENT_IDLE_TIMEOUT_S if c.authed else UNAUTH_TIMEOUT_S
            if now - c.last_rx > limit:
                self._close(c, "idle timeout")
                continue
            self._flush(c)

    def _accept(self, now):
        while True:
            try:
                sock, addr = self.listener.accept()
            except (BlockingIOError, InterruptedError):
                return
            except socket.error as e:
                if e.args and e.args[0] in (errno.EAGAIN, errno.EWOULDBLOCK):
                    return
                self.log("accept error: %r" % (e,))
                return
            sock.setblocking(False)
            try:
                sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            except Exception:
                pass
            if len(self.clients) >= MAX_CLIENTS:
                try:
                    sock.send(b'{"t":"error","reason":"busy"}\n')
                except Exception:
                    pass
                sock.close()
                continue
            c = _Client(sock, addr, now)
            self.clients.append(c)
            self._send(c, {"t": "hello", "v": PROTOCOL_VERSION,
                           "server": "Thaalam", "nonce": c.nonce,
                           "live": self.live_version})

    def _read(self, c, now):
        while True:
            try:
                data = c.sock.recv(4096)
            except (BlockingIOError, InterruptedError):
                break
            except socket.error as e:
                if e.args and e.args[0] in (errno.EAGAIN, errno.EWOULDBLOCK):
                    break
                self._close(c, "recv error")
                return
            if not data:
                self._close(c, "peer closed")
                return
            c.last_rx = now
            c.rbuf += data
            if len(c.rbuf) > MAX_LINE_BYTES * 4:
                self._close(c, "input too large")
                return
        while b"\n" in c.rbuf and not c.closing:
            line, c.rbuf = c.rbuf.split(b"\n", 1)
            if len(line) > MAX_LINE_BYTES:
                self._close(c, "line too long")
                return
            line = line.strip()
            if not line:
                continue
            try:
                msg = json.loads(line.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                self._send(c, {"t": "error", "reason": "bad json"})
                continue
            if not isinstance(msg, dict):
                continue
            try:
                self._handle(c, msg, now)
            except Exception as e:  # never let a bad message kill the script
                self.log("handler error: %r" % (e,))
                self._send(c, {"t": "error", "reason": "internal"})

    # ----- protocol --------------------------------------------------------

    def _handle(self, c, msg, now):
        kind = msg.get("t")
        if kind == "ping":
            self._send(c, {"t": "pong", "id": msg.get("id")})
            return
        if not c.authed:
            if kind in ("auth", "pair"):
                self._handle_auth(c, msg, now, pairing=(kind == "pair"))
            else:
                self._send(c, {"t": "auth_required"})
            return
        if kind == "get_state":
            self._send_state(c, force=True)
        elif kind in ("tempo_delta", "set_tempo", "set_metronome", "ramp", "stop_ramp"):
            self._handle_command(c, kind, msg)
        else:
            self._send(c, {"t": "error", "reason": "unknown message"})

    def _locked(self, now):
        return now < self.locked_until

    def _record_failure(self, now):
        self.auth_failures = [t for t in self.auth_failures if now - t < AUTH_LOCKOUT_S]
        self.auth_failures.append(now)
        if len(self.auth_failures) >= MAX_AUTH_FAILURES:
            self.locked_until = now + AUTH_LOCKOUT_S
            self.auth_failures = []
            self.notify("Thaalam: too many failed pairing attempts, locked for 60 s")

    def _handle_auth(self, c, msg, now, pairing):
        if self._locked(now):
            self._send(c, {"t": "auth_fail", "reason": "locked"})
            self._close(c, "auth locked")
            return
        # Re-read pairing data so code changes / revocations made with the Mac
        # tool apply immediately. Tiny file, read only at auth time.
        self.config.load()
        device = msg.get("device")
        mac = msg.get("mac")
        if not (isinstance(device, str) and 0 < len(device) <= 64 and isinstance(mac, str)):
            self._send(c, {"t": "auth_fail", "reason": "bad request"})
            self._close(c, "bad auth")
            return
        if pairing:
            key = self.config.pairing_code
        else:
            key = self.config.device_token(device)
            if key is None:
                self._send(c, {"t": "auth_fail", "reason": "unknown device"})
                self._close(c, "unknown device")
                return
        expected = hmac_hex(key, c.nonce)
        if not hmac.compare_digest(expected, mac.lower()):
            self._record_failure(now)
            reason = "bad code" if pairing else "bad token"
            self._send(c, {"t": "auth_fail", "reason": reason})
            self._close(c, "auth failed")
            return
        if pairing:
            name = msg.get("name")
            if not isinstance(name, str):
                name = "iPhone"
            token = self.config.add_device(device, name[:64])
            self._send(c, {"t": "paired", "token": token})
            self.notify("Thaalam: paired %s" % name[:64])
        clock = msg.get("clock")
        if isinstance(clock, (int, float)) and not isinstance(clock, bool):
            c.clock_offset_ms = self.wall_ms() - int(clock)
        c.authed = True
        c.device = device
        self._send(c, {"t": "auth_ok"})
        # Fresh read of Ableton's real state. Nothing is written.
        self.state = self._read_state()
        self._send_state(c, force=True)

    def _expired(self, c, msg):
        ts = msg.get("ts")
        if c.clock_offset_ms is None or not isinstance(ts, (int, float)) or isinstance(ts, bool):
            return True  # commands must be timestamped
        age = self.wall_ms() - (int(ts) + c.clock_offset_ms)
        return age > COMMAND_MAX_AGE_MS

    def _handle_command(self, c, kind, msg):
        cid = msg.get("id")
        if not isinstance(cid, int) or isinstance(cid, bool):
            self._send(c, {"t": "error", "reason": "missing id"})
            return
        if cid > c.last_id:
            c.last_id = cid
        if self._expired(c, msg):
            self._send_result(c, cid, False, "expired")
            return
        try:
            if kind in ("tempo_delta", "set_tempo", "ramp", "stop_ramp"):
                # Any tempo command replaces a running ramp.
                self.ramp = None
            if kind == "ramp":
                target, seconds = msg.get("target"), msg.get("seconds")
                if (not _is_number(target) or not (MIN_TEMPO <= target <= MAX_TEMPO)
                        or not _is_number(seconds) or not (0 < seconds <= MAX_RAMP_SECONDS)):
                    self._send_result(c, cid, False, "bad ramp")
                    return
                start = float(self.song.get_tempo())
                self.ramp = {"start": start, "target": float(target), "t0": self.clock(),
                             "seconds": float(seconds), "last": start}
            elif kind == "stop_ramp":
                pass
            elif kind == "tempo_delta":
                delta = msg.get("delta")
                if not _is_number(delta) or abs(delta) > MAX_DELTA or delta == 0:
                    self._send_result(c, cid, False, "bad delta")
                    return
                # Apply relative to Ableton's CURRENT tempo, read right now on
                # Live's thread, so rapid taps compound correctly and never use
                # a stale phone-side value.
                target = _clamp(self.song.get_tempo() + float(delta))
                self.song.set_tempo(target)
            elif kind == "set_tempo":
                bpm = msg.get("bpm")
                if not _is_number(bpm) or not (MIN_TEMPO <= bpm <= MAX_TEMPO):
                    self._send_result(c, cid, False, "bad bpm")
                    return
                self.song.set_tempo(float(bpm))
            elif kind == "set_metronome":
                on = msg.get("on")
                if not isinstance(on, bool):
                    self._send_result(c, cid, False, "bad value")
                    return
                # Explicit desired state, never a toggle.
                if bool(self.song.get_metronome()) != on:
                    self.song.set_metronome(on)
        except Exception as e:
            self.log("command %s failed: %r" % (kind, e))
            self._send_result(c, cid, False, "ableton error")
            return
        self._send_result(c, cid, True, None)

    def _step_ramp(self, now):
        r = self.ramp
        if r is None:
            return
        try:
            current = float(self.song.get_tempo())
            if abs(current - r["last"]) > RAMP_TAKEOVER_BPM:
                self.ramp = None  # someone else moved the tempo: yield to them
                return
            progress = min(1.0, (now - r["t0"]) / r["seconds"])
            value = round(r["start"] + (r["target"] - r["start"]) * progress, 2)
            if progress >= 1.0:
                value = r["target"]
                self.ramp = None
            if value != current:
                self.song.set_tempo(value)
            r["last"] = float(self.song.get_tempo())
        except Exception as e:
            self.log("ramp step failed: %r" % (e,))
            self.ramp = None

    def _ramp_info(self):
        r = self.ramp
        if r is None:
            return None
        left = max(0.0, r["seconds"] - (self.clock() - r["t0"]))
        return {"target": round_tempo(r["target"]), "seconds_left": round(left, 1)}

    def _send_result(self, c, cid, ok, reason):
        # Result always carries a fresh read-back of Ableton's real values.
        # The state message (sent first, carrying "ack" = this id) is what the
        # phone uses to clear the pending command; this result explains it.
        state = self._read_state()
        self._refresh_state()
        out = {"t": "result", "id": cid, "ok": ok,
               "tempo": state["tempo"], "metronome": state["metronome"]}
        if reason:
            out["reason"] = reason
        self._send(c, out)

    # ----- state -----------------------------------------------------------

    def _read_state(self):
        return {"tempo": round_tempo(self.song.get_tempo()),
                "metronome": bool(self.song.get_metronome()),
                "playing": bool(self.song.is_playing()),
                "ramp": self._ramp_info()}

    def _refresh_state(self):
        """Poll Live each tick; broadcast only when something changed.

        Polling (rather than relying only on listeners) also catches changes
        made by the music director, by Link peers, or by automation.
        """
        try:
            current = self._read_state()
        except Exception as e:
            self.log("state read failed: %r" % (e,))
            return
        if current != self.state:
            self.state = current
            self.seq += 1
        for c in self.clients:
            if c.authed:
                self._send_state(c)

    def _send_state(self, c, force=False):
        if self.state is None:
            self.state = self._read_state()
            self.seq += 1
        key = (self.seq, self.state["tempo"], self.state["metronome"],
               self.state["playing"], c.last_id)
        if not force and c.last_sent_state == key:
            return
        c.last_sent_state = key
        msg = {"t": "state", "seq": self.seq, "ack": c.last_id}
        msg.update(self.state)
        self._send(c, msg)

    # ----- io --------------------------------------------------------------

    def _send(self, c, obj):
        if c.closing:
            return
        c.wbuf += (json.dumps(obj, separators=(",", ":")) + "\n").encode("utf-8")
        if len(c.wbuf) > 256 * 1024:
            self._close(c, "client not reading")
            return
        self._flush(c)

    def _flush(self, c):
        while c.wbuf and not c.closing:
            try:
                n = c.sock.send(c.wbuf)
            except (BlockingIOError, InterruptedError):
                return
            except socket.error as e:
                if e.args and e.args[0] in (errno.EAGAIN, errno.EWOULDBLOCK):
                    return
                self._close(c, "send error")
                return
            if n <= 0:
                return
            c.wbuf = c.wbuf[n:]

    def _close(self, c, why):
        if c.closing:
            return
        if c.wbuf:
            try:
                c.sock.send(c.wbuf)  # best effort, non-blocking
            except Exception:
                pass
        c.closing = True
        try:
            c.sock.close()
        except Exception:
            pass
        if c in self.clients:
            self.clients.remove(c)
        # Any unread commands in c.rbuf die with the connection: never replayed.
        self.log("client %s closed: %s" % (c.addr, why))


def _is_number(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and v == v


def _clamp(bpm):
    return max(MIN_TEMPO, min(MAX_TEMPO, float(bpm)))
