"""Ableton Live control surface glue for Thaalam.

Only Song.tempo and Song.metronome are ever written (both documented, settable
Live Object Model properties). Song.is_playing is read for display only.
No transport, mixer, track or preference is touched.
"""

import os
import socket as _socket

import Live
from _Framework.ControlSurface import ControlSurface

from .server import RemoteServer, ConfigStore, SongAdapter
from .bonjour import BonjourAdvertiser

CONFIG_PATH = os.path.expanduser(
    "~/Library/Application Support/Thaalam/config.json")
# Live's status bar message fades after a few seconds, so the pairing code is
# repeated every this many update_display ticks (~100 ms each) until a phone pairs.
CODE_REPEAT_TICKS = 100


class _LiveSong(SongAdapter):
    def __init__(self, song_getter):
        self._song = song_getter

    def get_tempo(self):
        return self._song().tempo

    def set_tempo(self, bpm):
        self._song().tempo = float(bpm)

    def get_metronome(self):
        return self._song().metronome

    def set_metronome(self, on):
        self._song().metronome = bool(on)

    def is_playing(self):
        return self._song().is_playing


def _live_version():
    try:
        app = Live.Application.get_application()
        return "%d.%d.%d" % (app.get_major_version(), app.get_minor_version(),
                             app.get_bugfix_version())
    except Exception:
        return "unknown"


class Thaalam(ControlSurface):
    def __init__(self, c_instance):
        ControlSurface.__init__(self, c_instance)
        self._server = None
        self._bonjour = None
        self._config = None
        self._ticks = 0
        try:
            config = ConfigStore(CONFIG_PATH)
            self._config = config
            self._server = RemoteServer(
                _LiveSong(self.song), config,
                log=self._log, notify=self.show_message,
                live_version=_live_version())
            self._server.start()
            host = _socket.gethostname().split(".")[0] or "Mac"
            self._bonjour = BonjourAdvertiser(
                "Thaalam (%s)" % host, self._server.port, log=self._log)
            self._bonjour.start()
            if config.data.get("devices"):
                self.show_message("Thaalam ready on port %d" % self._server.port)
            else:
                # Only advertise the code until the first device is paired.
                self.show_message("Thaalam ready on port %d. Pairing code: %s"
                                  % (self._server.port, config.pairing_code))
        except Exception as e:
            self._log("startup failed: %r" % (e,))
            self.show_message("Thaalam failed to start: %s" % (e,))
            self._server = None

    def _log(self, msg):
        self.log_message("[Thaalam] " + msg)

    def update_display(self):
        ControlSurface.update_display(self)
        if self._server is not None:
            try:
                self._server.tick()
            except Exception as e:
                self._log("tick error: %r" % (e,))
            self._ticks += 1
            if (self._ticks % CODE_REPEAT_TICKS == 0 and self._config is not None
                    and not self._config.data.get("devices")):
                self.show_message("Thaalam ready. Pairing code: %s (enter it in the Thaalam app)"
                                  % self._config.pairing_code)

    def disconnect(self):
        # Close network resources only. Ableton keeps playing untouched.
        if self._bonjour is not None:
            self._bonjour.stop()
            self._bonjour = None
        if self._server is not None:
            self._server.stop()
            self._server = None
        ControlSurface.disconnect(self)
