"""Bonjour advertisement via macOS's built-in /usr/bin/dns-sd.

Runs dns-sd in a tiny shell watchdog that exits when Live exits, so a crash
cannot leave a stale advertisement behind. If anything fails, discovery is
simply unavailable and the iPhone app's manual IP entry still works.
"""

import os
import subprocess

SERVICE_TYPE = "_thaalam._tcp"
DNS_SD = "/usr/bin/dns-sd"


class BonjourAdvertiser(object):
    def __init__(self, name, port, log=None):
        self.name = name
        self.port = int(port)
        self.log = log or (lambda m: None)
        self.proc = None

    def start(self):
        if not os.path.exists(DNS_SD):
            self.log("dns-sd not found; Bonjour discovery disabled")
            return
        script = (
            '"$0" -R "$1" "$2" local "$3" >/dev/null 2>&1 & D=$!; '
            'while kill -0 "$4" 2>/dev/null; do sleep 3; done; kill "$D" 2>/dev/null'
        )
        args = ["/bin/sh", "-c", script, DNS_SD, self.name, SERVICE_TYPE,
                str(self.port), str(os.getpid())]
        try:
            self.proc = subprocess.Popen(
                args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL, close_fds=True)
            self.log("Bonjour advertising '%s' on port %d" % (self.name, self.port))
        except Exception as e:
            self.proc = None
            self.log("Bonjour start failed: %r" % (e,))

    def stop(self):
        proc, self.proc = self.proc, None
        if proc is None:
            return
        try:
            # Kill the watchdog's child dns-sd too.
            subprocess.call(["/usr/bin/pkill", "-P", str(proc.pid)],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            proc.terminate()
        except Exception:
            pass
