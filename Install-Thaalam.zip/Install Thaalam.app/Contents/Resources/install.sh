#!/bin/bash
# Copies the Thaalam Remote Script into Ableton's User Library.
# Reads Live's Library.cfg only to find the User Library; changes no Live setting.
set -eu
SRC="$1"
LIB="$HOME/Music/Ableton/User Library"
while IFS= read -r CFG; do
  BLOCK=$(tr '\n' ' ' < "$CFG" | sed -n 's/.*<UserLibrary>\(.*\)<\/UserLibrary>.*/\1/p')
  [ -n "$BLOCK" ] || continue
  P=$(printf '%s' "$BLOCK" | sed -n 's/.*<ProjectPath Value="\([^"]*\)".*/\1/p')
  N=$(printf '%s' "$BLOCK" | sed -n 's/.*<ProjectName Value="\([^"]*\)".*/\1/p')
  [ -n "$P" ] || continue
  if [ -n "$N" ] && [ -d "$P/$N" ]; then LIB="$P/$N"; break; fi
  if [ -d "$P" ] && [ "$(basename "$P")" = "User Library" ]; then LIB="$P"; break; fi
done < <(ls -t "$HOME"/Library/Preferences/Ableton/Live\ */Library.cfg 2>/dev/null || true)

DEST="$LIB/Remote Scripts/Thaalam"
if [ -e "$DEST" ] && [ ! -e "$DEST/.thaalam-marker" ]; then
  echo "A folder named Thaalam already exists in Remote Scripts and was not installed by Thaalam, so it was left alone: $DEST" >&2
  exit 3
fi
mkdir -p "$LIB/Remote Scripts"
rm -rf "$DEST"
cp -R "$SRC" "$DEST"
find "$DEST" -name "__pycache__" -prune -exec rm -rf {} +
touch "$DEST/.thaalam-marker"
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null || true

# Pairing code: reuse the one the script stores, or create the file the same way
# the script would (ConfigStore format), so the installer can show the code.
CONF_DIR="$HOME/Library/Application Support/Thaalam"
CONF="$CONF_DIR/config.json"
CODE=""
[ -f "$CONF" ] && CODE=$(sed -n 's/.*"pairing_code": *"\([0-9]\{6\}\)".*/\1/p' "$CONF" | head -1)
if [ -z "$CODE" ] && [ ! -f "$CONF" ]; then
  N=$(od -An -N4 -tu4 /dev/urandom | tr -d ' ')
  CODE=$(printf '%06d' $((N % 1000000)))
  mkdir -p "$CONF_DIR" && chmod 700 "$CONF_DIR"
  (umask 077; printf '{\n  "devices": {},\n  "pairing_code": "%s",\n  "port": 47800\n}\n' "$CODE" > "$CONF")
fi
echo "$DEST"
echo "$CODE"
